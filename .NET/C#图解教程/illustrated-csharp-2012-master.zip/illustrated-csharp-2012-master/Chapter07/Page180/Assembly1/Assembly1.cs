﻿using System;

namespace BaseClassNS
{
   public class MyBaseClass
   {
      public void PrintMe()
      {
         Console.WriteLine( "I am MyBaseClass" );
      }
   }
}
