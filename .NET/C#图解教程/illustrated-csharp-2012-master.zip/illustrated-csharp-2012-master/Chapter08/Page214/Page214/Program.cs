﻿using System;

class Program
{
   static void Main( )
   {
      int x = 5, y = 4;
      Console.WriteLine( "x == x is {0}", x == x );
      Console.WriteLine( "x == y is {0}", x == y );
   }
}

