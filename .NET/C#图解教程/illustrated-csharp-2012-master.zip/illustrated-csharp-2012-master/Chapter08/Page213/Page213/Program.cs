﻿using System;

class Program
{
   static void Main( string[] args )
   {
      Console.WriteLine( "0.0f % 1.5f is {0}", 0.0f % 1.5f );
      Console.WriteLine( "0.5f % 1.5f is {0}", 0.5f % 1.5f );
      Console.WriteLine( "1.0f % 1.5f is {0}", 1.0f % 1.5f );
      Console.WriteLine( "1.5f % 1.5f is {0}", 1.5f % 1.5f );
      Console.WriteLine( "2.0f % 1.5f is {0}", 2.0f % 1.5f );
      Console.WriteLine( "2.5f % 1.5f is {0}", 2.5f % 1.5f );
   }
}

